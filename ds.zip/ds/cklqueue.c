#include<stdio.h>
int cklinsert(int[],int *,int*,int,int);
int ckldel(int[],int *,int *);
void main()
{
int n=3,a[n],r=0,f=0,num,x;
while(1)
{
	printf("enter the num 0,1 for enque and deque");
	scanf("%d",&num);
switch(num)
	{
	case 0:
		while(1)
		{
			printf("enter element to be pushed");
			scanf("%d",&x);
			if(cklinsert(a,&r,&f,n,x)!=0)
				{
				printf("element is pushed");
				}
				//break;

			else
			{
			break;
			}
		}
				//break;

			

	break;

	case 1:
		while(1)
			{
			int p=ckldel(a,&f,&r);
			if(p!=0)
			{
			printf("the element dequeued is %d\n",p);
			}
			else
			{
			break;
			}
			}
	break;
	case 2:
	exit(0);
	break;
	}
}
}

int cklinsert(int s[],int *r,int *f,int n,int e)
{	if(*r==n){
	*r=1;

	}
	else{
	*r=*r+1;

	}
	if(*r==*f)
	{
	printf("overflow");

	return 0;
	}
	else
	{
	if(*f==0)
	*f=1;
	s[*r]=e;

	return s[*r];
}
}
	

int  ckldel(int s[],int *f,int *r)
{ 	
	int z;
	
if (*f == 0)
	{
        printf("The circular queue is empty\n");
	return 0;
	}
	
	
else{
	
     		if (*f == *r)
		{
		printf("hi");
          	 z=s[*f];
         	 // *f = 0;
         	//  *r = 0;
}
		else{
			z=s[*f];
			*f=*f+1;}
	return z;
	    
	}



	
}
