#include<stdio.h>
int isfull();

int push(int);
int n=3;
int s[3],top=0;
void main()
{
while(1)
{
int x;
printf("enter ekements to push\n");
scanf("%d",&x);
if(push(x)==0)
break;
else
{
printf("element pushed\n");
}
}
}
int isfull()
{
if(top>=n)
return 1;
else
return 0;
}
int push(int x)
{
if(isfull()==0)
{
top=top+1;
s[top]=x;
return 1;
}
else
{
printf("stack overflowed");

return 0;
}
}

