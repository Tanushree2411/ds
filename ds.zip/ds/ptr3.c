#include<stdio.h>
void main()
{
int a=10,b=20,*p,*q,sum;
printf("value of a and b is %d %d \n",a,b);


p=&a;
q=&b;
sum=*p+*q;
printf("sum value of a and b is %d  \n",sum);



}
