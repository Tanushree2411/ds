#include<stdio.h>

int push(int [],int *,int);

void main()

{
int n=3;
int s[3]={1,2,3},top=n;
//int x;
while(1)
{
	//printf("enter ekements to push\n");
	//scanf("%d",&x);
	if(pop(s,&top,n)==0)
	break;
	else
	{
	printf("element popped\n");
	}
}
//for(int i=n;i>=1;i--)
//{
//printf("%d",s[i]);
//}
}
int pop(int a[],int *t,int n)
{
if(*t>0)
{
*t=*t-1;
//a[*t]=e;
printf("popped elemetn is %d\n",a[*t+1]);
printf("top is %d",*t);
return 1;
}
else
{
printf("stack underflowed");

return 0;
}
}

