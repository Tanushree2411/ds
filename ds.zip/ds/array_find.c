#include<stdio.h>
void main()
{
int arr[5]={1,2,3,4,5};
int num;
printf("enter num");
scanf("%d",&num);
for(int i=0;i<5;i++)
{
if(num==arr[i])
{
printf("the index is %d",i);
}
}
}
