#include<stdio.h>
void main()
{
int arr[3]={1,2,3};
int min;
for(int i=0;i<3;i++)
{
if(min>arr[i])
{
min=arr[i];
}
}
printf("min is %d",min);
}
