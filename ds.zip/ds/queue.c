#include<stdio.h>
int enqueue(int[],int *,int*,int,int);
int dequeue(int[],int *,int *);
void main()
{
int n=3,a[n+1],r=-1,f=-1,num,x;
while(1)
{
	printf("enter the num 0,1 for enque and deque");
	scanf("%d",&num);
switch(num)
	{
	case 0:
		while(1)
		{
			printf("enter element to be pushed");
			scanf("%d",&x);
			if(enqueue(a,&r,&f,n,x)!=0)
				{
				printf("element is pushed");
				}
				//break;

			else
			{
			break;
			}
		}

	break;

	case 1:
		while(1)
			{
			int p=dequeue(a,&f,&r);
			if(p!=0)
			{
			printf("the element dequeued is %d\n",p);
			}
			else
			{
			break;
			}
			}
	break;
	case 2:
	exit(0);
	break;
	}
}
}

int enqueue(int s[],int *r,int *f,int n,int e)
{
	if(*r==n-1)
	{ 
	return 0;
	//printf("queue is full");
	}
	else
	{
		if(*f==-1)
		{
		*f=0;
		}
	
		*r=*r+1;
		s[*r]=e;
		printf("element queued");
		return 1;
	
	}
}

int dequeue(int s[],int *f,int *r)
{int y;
	if(*f==-1)
	{
	printf("queue is empty");
	return 0;
	}
	
	else
	{
	printf("We have dequeued : %d\n", s[*f]);
        y=s[*f];

		if(*f>=*r)
		{
			*f = -1;
			*r = -1;
		}
		else{

	        *f = *f+ 1;}
        
        
	return y;
	}
}

