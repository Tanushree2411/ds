#include<stdio.h>
void main()
{
int a=10,*p;
p=&a;

printf("value of a  is %d %d \n",a,*p);
printf("address of a is %d \n",p);

}
