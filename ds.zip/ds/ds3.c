/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
/*{
  int b[3][3];
  char str[6];
  int k;
 
  printf("enter a string");
  scanf("%s",&str[6]);
   k=str[2]-'0';
  int l=str[4]-'0';
  printf("%d %d",k,l);
  
  for(int i=0;i<3;i++)
  {
      for(int j=0;j<3;j++)
      {
         if(i==str[2]-'0' && j==str[4]-'0')
         {
             printf("%d",i);
             printf("%d",j);
             b[i][j]=3;
             
         }
        // else if(b[i][j]!=0)
         ///{
            // break;
        // }
        // else
         //{
           //  b[i][j]=0;
         //}
        printf("%d",b[i][j]);
      }
    printf("\n");
  }

}*/
{
    char str[6],str1[6];
    int count=0;
    int b[3][3]={0,0,0,0,0,0,0,0,0};
    int c[3][3]={0,0,0,0,0,0,0,0,0};
    for(int k=0;k<5;k++)
    {
    scanf("%s",&str);
    for(int i=0;i<3;i++)
    {
      for(int j=0;j<3;j++)
      {
         if(i==str[2]-'0' && j==str[4]-'0')
         {
             //printf("%d",i);
             //printf("%d",j);
            b[i][j]=b[i][j]+str[0]-'0';
             
             
         }
      }
         printf("%d",b[i][j]);
    }
    printf("\n");

    //scanf("
    //goto
  }
  
  for(int k=0;k<5;k++)
  {
    scanf("%s",&str1);
    for(int i=0;i<3;i++)
   {
      for(int j=0;j<3;j++)
       {
         if(i==str1[2]-'0' && j==str1[4]-'0')
         {
             //printf("%d",i);
             //printf("%d",j);
             c[i][j]=c[i][j]+str1[0]-'0';
         }
         printf("%d",c[i][j]);
       }
    }
    printf("\n");
  }

    //scanf("
    //goto
        
        
  return 0;
}
    

