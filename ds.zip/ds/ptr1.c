#include<stdio.h>
void main()
{
int a=10,b=20,*p,*q,temp;
printf("value of a and b is %d %d \n",a,b);


p=&a;
q=&b;
temp=*q;
*q=*p;
*p=temp;

printf("value of a and b is %d %d \n",a,b);



}
