#include<stdio.h>
int dqinsert_f(int[],int *,int*,int,int);
int dqdelete_r(int[],int *,int *);
void main()
{
int n=3,a[n],r=0,f=0,num,x;
while(1)
{
	printf("enter the num 0,1 for enque and deque");
	scanf("%d",&num);
switch(num)
	{
	case 0:
		while(1)
		{
			printf("enter element to be pushed");
			scanf("%d",&x);
			if(dqinsert_f(a,&r,&f,n,x)!=0)
				{
				printf("element is pushed");
				}
				//break;

			else
			{
			break;
			}
		}
				//break;

			

	break;

	case 1:
		while(1)
			{
			int p= dqdelete_r(a,&f,&r);
			if(p!=0)
			{
			printf("the element dequeued is %d\n",p);
			}
			else
			{
			break;
			}
			}
	break;
	case 2:
	exit(0);
	break;
	}
}
}

int dqinsert_f(int s[],int *r,int *f,int n,int e)
{	if(*f=0){
	printf("empty");
	return 0;

	}
	if(*f=1){
	printf("overflow");
	return 0;}
	else{
	*f=*f-1;
	s[*f]=e;
	return s[*f];}
}
	

int dqdelete_r(int s[],int *f,int *r)
{ 	
	int z;
	
if (*r == 0)
	{
        printf("underflow\n");
	return 0;
	}
z=s[*r];
if(*r==*f)
{
*r=*f=0;
}
else
*r=*r-1;
return z;
	
	    
	
}
