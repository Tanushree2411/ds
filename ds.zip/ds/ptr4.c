#include<stdio.h>
void main()
{
int a[3]={1,2,3};
int *p,i,sum;
p=a;
for(i=0;i<3;i++)
{
sum=sum+*p;
p++;
}
printf("sum is %d",sum);
}



