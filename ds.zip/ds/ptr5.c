#include<stdio.h>
void main()
{
int a[5]={5,6,8,9,4};
int *p[5],i,j,temp;
for(i=0;i<5;i++)
{

p[i]= &a[i];
}
for(i=0;i<5;i++)
{
for(j=i+1;j<5;j++)
{
if(*p[i]>*p[j])
{
temp=*p[i];
*p[i]=*p[j];
*p[j]=temp;
}
}
}
for(int i=0;i<5;i++)
{
printf("%d",*p[i]);
}
}
