#include<stdio.h>
void main()
{
int id,newmarks;
int marks[5]={21,45,36,78,56};
printf("Enter id \n");
scanf("%d",&id);
printf("current marks is %d \n",marks[id]);
printf("updTED marks");
scanf("%d",&newmarks);
marks[id]=newmarks;
printf("updated marks is %d \n",marks[id]);
}
