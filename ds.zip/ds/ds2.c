#include<stdio.h>
void main()
{
int base_address;
int no_of_rows,no_of_columns,i,j,result;
int c;
int size=2;
printf("enter base address");
scanf("%d",&base_address);
printf("enter total rows");
scanf("%d",&no_of_rows);
printf("enter total columns");
scanf("%d",&no_of_columns);
printf("enter ith row of element");
scanf("%d",&i);
printf("enter j th column");
scanf("%d",&j);
printf("enter 1 or 0 for row wise or column wisr");
scanf("%d",&c);
if(c==1)
{
result=base_address+(((i-1)*no_of_columns+(j-1))*size);
printf("%d",result);

}
else
{
result=base_address+(((j-1)*no_of_rows+(i-1))*size);
}
}



