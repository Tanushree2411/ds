
#include <stdio.h>

int main()

{
    char str[6];
    int b[3][3]={0,0,0,0,0,0,0,0,0};
    int c[3][3]={0,0,0,0,0,0,0,0,0};
    int sum[3][3];
    char str1[6];
    for(int k=0;k<5;k++)
    {
    scanf("%s",&str);

    for(int i=0;i<3;i++)
  {
      for(int j=0;j<3;j++)
      {
         if(i==str[2]-'0' && j==str[4]-'0')
         {
             //printf("%d",i);
             //printf("%d",j);
             b[i][j]=b[i][j]+str[0]-'0';
             
             
         }
        
         printf("%d",b[i][j]);
      }
    printf("\n");

    //scanf("
    //goto
  }
        
    }
printf("enter the terms for 2nd polynomial");

int count;
int l;

for(count=0;count<5;count++){
    


    {
    scanf("%s",&str1);

    for(int i=0;i<3;i++)
  {
      for(int j=0;j<3;j++)
      {
         if(i==str1[2]-'0' && j==str1[4]-'0')
         {
             //printf("%d",i);
             //printf("%d",j);
             c[i][j]=c[i][j]+str1[0]-'0';
             
             
         }
        
         printf("%d",c[i][j]);
      }
    printf("\n");

    //scanf("
    //goto
  }
        
    }
}
for(int i=0;i<3;i++)
{
for(int j=0;j<3;j++)
{ 
sum[i][j]=b[i][j]+c[i][j];
}
}
for(int i=0;i<3;i++)
{
for(int j=0;j<3;j++)
{
printf("%d",sum[i][j]);
}
printf("\n");
}
for(int i=0;i<3;i++)
{
for(int j=0;j<3;j++)
{
    if(sum[i][j]!=0)
    {
        char f,t,s,x='x',y='y';
        f=sum[i][j]+'0';
        t=i+'0';
        printf("%c",t);
        s=j+'0';
        strcat(x,t);
        strcat(y,s);
        strcat(x,y);
       printf("%s", strcat(f,x));
                     
    
    }
}
}
  return 0;
}
    

