#include<stdio.h>
void main()
{
int address,i,size=2,result;
printf("enter the address");
scanf("%d",&address);
printf("enter the index i of element");
scanf("%d",&i);
result=(address+(size*(i-1)));
printf("%d",result);
}
